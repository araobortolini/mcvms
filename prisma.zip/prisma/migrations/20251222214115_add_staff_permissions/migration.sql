-- AlterTable
ALTER TABLE "User" ADD COLUMN "permissions" TEXT DEFAULT '[]';
