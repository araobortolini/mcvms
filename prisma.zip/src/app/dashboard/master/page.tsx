﻿export default function MasterPage() { return <h1>Painel Master</h1> }
